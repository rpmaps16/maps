package com.rpmaps;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class SignupActivity extends Activity {


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_signup);

	}

	public void btnSignUpOnclick(View view) {

	}
}